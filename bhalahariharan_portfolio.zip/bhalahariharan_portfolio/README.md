# Bhalahariharan M S — Portfolio

A responsive neo-brutalist portfolio website built with plain HTML, CSS and JavaScript.

## Preview locally
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. Internet is needed for the Google Fonts import; system fallbacks are included.

## Before publishing
- Replace the LinkedIn placeholder URL with your actual profile URL.
- Add a GitHub profile link and real project links when ready.
- Update your internship description and add concrete contributions only when you can publicly share them.
- Consider adding a professional headshot or project screenshots.
- Deploy the folder using GitHub Pages, Netlify or Vercel.

The site intentionally describes skills as areas being explored, rather than claiming expertise.
